function startProgram() {
  var avsnittet = document.getElementById("avsnittet");
  var nytt = '<a href="#">død  lenke</a>';
  avsnittet.innerHTML = nytt;
}
